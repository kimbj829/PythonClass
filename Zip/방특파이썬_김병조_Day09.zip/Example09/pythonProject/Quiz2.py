'''

*****
****
***
**
*

숙제
피라미드 출력
     *
    ***
   *****
  *******
'''


for i in range(5, 0, -1):
    for j in range(1, 2):
        print("*" * (i*j));

'''

for i in range(6, 0, -1):
    for j in range(1, i-1 + 1):
        print("*", end ='')
    print();

'''
