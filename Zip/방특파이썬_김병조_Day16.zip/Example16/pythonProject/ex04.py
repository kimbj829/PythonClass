file = open('D:/python_kimbyeongjo/upload/test.txt','a');
file.write("test input");
file.close();