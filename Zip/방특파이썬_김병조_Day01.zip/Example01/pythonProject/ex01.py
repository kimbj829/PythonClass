# 실행 단축키 Ctrl+Shift+F10
print("Hello, World");
print("Python is very easy");
a = int(input('숫자를 입력해주세요\n'));

print("입력하신 숫자는", a, '입니다.');
