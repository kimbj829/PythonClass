'''
PYTHON 이라는 문자열을 거꾸로 뒤집어 출력
'''

string = "PYTHON";
print(string[::-1]);