num1 = int(input("숫자입력 >> "));
num2 = int(input("숫자입력 >> "));

print("두 수의 덧셈 결과 :", num1 + num2);