#리스트 인덱싱

array = [10, 20, 30, 40, 50]
print("list 1번째 요소 :", array[0]);
print("list 2번째 요소 :", array[1]);
print("list 3번째 요소 :", array[2]);
print("list 4번째 요소 :", array[3]);
print("list 5번째 요소 :", array[4]);
print("arrays 리스트 길이 :", len(array));

print()

print("list 마지막 요소 :", array[-1]);
print("list 4번째 요소 :", array[-2]);
print("list 3번째 요소 :", array[-3]);
print("list 2번째 요소 :", array[-4]);
print("list 1번째 요소 :", array[-5]);


#for i in range(len(array)):
#    print("list %i번째 요소" %i, array[i]);