'''
다음 리스트에 저장되어 있는 값들의 평균을 구하세요
'''

nums = [10, 20, 30, 40, 50]

sum = nums[0] + nums[1] + nums[2] + nums[3] + nums[4];
avg = sum/5;
print("리스트 값의 평균 :", avg);

'''
sum1 = 0;
for i in range(len(nums)):
    sum1 = nums[i-1] + sum1;

avg1 = sum1;
print("리스트 값의 평균 :", avg);
'''