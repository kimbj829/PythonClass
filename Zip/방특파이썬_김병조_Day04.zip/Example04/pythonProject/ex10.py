a1 = 10;
a2 = 20;
print("a1의 값 :", a1); print("a2의 값 :", a2);

print();

temp = a1;
a1 = a2;
a2 = temp;
print("a1의 값 :", a1); print("a2의 값 :", a2);