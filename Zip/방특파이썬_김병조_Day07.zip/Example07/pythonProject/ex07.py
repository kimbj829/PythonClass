'''
난수 생성
'''
import random
print(random.randint(1, 10));