'''
# 초기값 감소
num = int(input("반복횟수입력 >>"))

while num > 0 :
    print(num);
    num = num - 1;
'''

'''
while문을 사용하여 1 ~ 100까지 짝수만 출력하세요!!
'''

i = 0;

while i < 100:
    i = i + 1;
    if i % 2 == 0:
        print(i);

'''
#입력 받은 숫자안에서 짝수만 출력
num = int(input("반복횟수입력 >> "));
i = 0;
while i < 100 :
    i = i + 1;
    if i % 2 == 0 :
        print(i);
        
'''



