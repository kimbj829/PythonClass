'''
range 함수는 stop 조건을 반드시 명시해 줘야 한다
'''

for i in range(1, 10, 1):
    print(i);

print();

for i in range(0+1, 101, 1):
    print(i);