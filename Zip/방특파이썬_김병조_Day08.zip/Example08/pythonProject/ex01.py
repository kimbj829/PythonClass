'''
range(start, stop, step)
- 초기값(start)을 생략하면 0번부터 시작한다.
- step 생락하면 자동으로 1씩 증가한다
- stop은 생략이 불가능하다
'''
for i in range(1, 11):
    print("Hello World", i);