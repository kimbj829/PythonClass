'''
*
**
***
****
*****
'''
for i in range(1, 2):
    for j in range(1, 6):
        print('*'*(i*j));


for i in range(1, 6):
    for j in range(1, i + 1, 1):
        print('*', end= '');
    print();