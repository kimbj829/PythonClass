year = int(input("연도를 입력해주세요(1~4000) : "));
print(year % 4);