# 초기값 감소
num = int(input("반복횟수입력 : "));

while num > 0:
    print(num);
    num = num - 1;