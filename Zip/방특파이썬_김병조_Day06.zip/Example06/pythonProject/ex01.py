money = True;

if money:
    print("택시를 타고 가라");
else :
    print("걸어가라");

age = int(input("나이입력 : "));
if age >= 60:
    print("노약자 입니다.");
else :
    print("노약자가 아닙니다.");
    