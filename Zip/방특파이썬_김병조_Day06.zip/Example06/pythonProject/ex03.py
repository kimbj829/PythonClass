money = 5000

if money >= 10000:
    print("택시를 타고 집에 갑니다.");

elif money >= 2000 and money < 10000:
    print("버스를 타고 집에 갑니다");
else :
    print("걸어서 집에 가라");
