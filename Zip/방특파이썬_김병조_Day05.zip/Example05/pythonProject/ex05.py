x = 10;
if x == 10:
    print("x는 10입니다.");
else :
    print("x는 10이 아닙니다");

num1 = 10;
num2 = 20;
if num1 > num2 :
    print("{}이 큽니다.".format(num1));
else :
    print("{}이 큽니다.".format(num2));