'''
변수를 선언하여
자신의 이름(str), 나이(int), 성별, 학교, 거주지를 출력하는 프로그램을 만드세요.
'''

name = "김병조";
age = 29;
gender = "남성";
college = "부산대";
address = "김해";

#print("이름 :", name, "나이 :", age, "성별 :",gender, "학교 :", college, "거주지 :", address);
print("이름 :", name); print(type(name));
print("나이 :", age); print(type(age));
print("성별 :",gender); print(type(gender));
print("학교 :", college); print(type(college));
print("거주지 :", address); print(type(address));
