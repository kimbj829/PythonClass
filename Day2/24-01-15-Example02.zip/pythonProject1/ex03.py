age = 30;
name = "홍길동";
pi = 3.14;
truth = False;

print(age); print(type(age));
print(name); print(type(name));
print(pi);
print(type(pi));
print(truth);
print(type(truth));