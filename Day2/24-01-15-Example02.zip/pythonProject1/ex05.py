'''
문자열 더해서 연결하기
'''

head = "Python";
tail = " is fun!";
result = head + tail; # str 2개를 이어서 하나의 str으로 합치기
print(result);

# 문자열 곱하기
str1 = "Python";
print(str1 * 4); # str1을 4번 반복해서 출력